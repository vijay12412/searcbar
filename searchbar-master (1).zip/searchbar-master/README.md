# searchbar
to create search bar
is useful to work in contact or phonebook
easy to search the values
